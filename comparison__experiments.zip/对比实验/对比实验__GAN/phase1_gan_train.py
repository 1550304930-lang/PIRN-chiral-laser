# -*- coding: utf-8 -*-
"""Phase 1: train a conditional GAN regression baseline on raw CSV mode order."""

from __future__ import annotations

import argparse
import os
import sys


CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
COMPARE_ROOT = os.path.dirname(CURRENT_DIR)
if COMPARE_ROOT not in sys.path:
    sys.path.insert(0, COMPARE_ROOT)

from baseline_common import (
    BaselineConfig,
    add_gan_train_args,
    add_train_args,
    apply_args_to_config,
    train_baseline,
)


def default_config() -> BaselineConfig:
    return BaselineConfig(
        model_name="GAN",
        model_dir=os.path.join(CURRENT_DIR, "Phase1_GAN_Models_RawModes"),
        analysis_dir=os.path.join(CURRENT_DIR, "Phase2_GAN_Analysis_RawModes"),
        epochs=400,
        learning_rate=8e-4,
        discriminator_lr=5e-4,
        weight_decay=1e-5,
        hidden_dim=128,
        num_layers=3,
        dropout=0.05,
        latent_dim=8,
        adv_weight=0.02,
        early_stop_patience=80,
    )


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Train a conditional GAN baseline without mode tracking.")
    add_train_args(parser)
    add_gan_train_args(parser)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    cfg = apply_args_to_config(default_config(), args, phase="train")
    train_baseline("gan", cfg, args.csv)


if __name__ == "__main__":
    main()
