# -*- coding: utf-8 -*-
"""Phase 2: plot validation diagnostics for the plain MLP baseline."""

from __future__ import annotations

import argparse
import os
import sys


CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
COMPARE_ROOT = os.path.dirname(CURRENT_DIR)
if COMPARE_ROOT not in sys.path:
    sys.path.insert(0, COMPARE_ROOT)

from baseline_common import BaselineConfig, add_plot_args, analyze_baseline, apply_args_to_config


def default_config() -> BaselineConfig:
    return BaselineConfig(
        model_name="MLP",
        model_dir=os.path.join(CURRENT_DIR, "Phase1_MLP_Models_RawModes"),
        analysis_dir=os.path.join(CURRENT_DIR, "Phase2_MLP_Analysis_RawModes"),
        hidden_dim=128,
        num_layers=4,
        dropout=0.05,
    )


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Plot validation diagnostics for the plain MLP baseline.")
    add_plot_args(parser)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    cfg = apply_args_to_config(default_config(), args, phase="plot")
    analyze_baseline("mlp", cfg, args.csv)


if __name__ == "__main__":
    main()
