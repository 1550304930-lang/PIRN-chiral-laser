# -*- coding: utf-8 -*-
"""Phase 2: plot validation diagnostics for the plain MLP baseline."""

from __future__ import annotations

import argparse
import os
import sys


CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
COMPARE_ROOT = os.path.dirname(CURRENT_DIR)
if COMPARE_ROOT not in sys.path:
    sys.path.insert(0, COMPARE_ROOT)

from baseline_common import BaselineConfig, add_plot_args, analyze_baseline, apply_args_to_config


def _integrate_validation_predictions_excel(analysis_dir: str) -> None:
    """Create plotting-friendly validation Excel files and MSE/MAE summary tables.

    Outputs:
    1) Validation_Predictions_All_Params.xlsx
       - Integrated_All_Modes: four modes stacked into shared result-parameter columns.
       - Original_Wide: original analyzer output kept for reference.

    2) Validation_MSE_MAE_By_Param.xlsx
       - Overall_All_Modes: MSE/MAE for RealFreq, ImagFreq, Q, S3, Gamma over all modes.
       - Per_Mode: MSE/MAE for the same parameters in each mode.
       - Column_Mapping: true/pred/error columns used for every parameter.
    """
    import math
    import re
    from collections import OrderedDict

    import pandas as pd

    excel_path = os.path.join(analysis_dir, "Validation_Predictions_All_Params.xlsx")
    if not os.path.exists(excel_path):
        print(f"[WARN] Cannot find {excel_path}; skip integrated Excel post-process and metric summary.")
        return

    def clean_name(name: object) -> str:
        return str(name).strip()

    def split_pandas_duplicate_suffix(name: str) -> tuple[str, int | None]:
        """Pandas renames duplicate Excel headers as name, name.1, name.2, ..."""
        match = re.match(r"^(.*)\.(\d+)$", name)
        if match:
            return match.group(1), int(match.group(2)) + 1
        return name, None

    def parse_mode_and_metric(name: object) -> tuple[int, str]:
        """Return (mode_id, mode-independent_metric_name)."""
        raw_name = clean_name(name)
        base_name, duplicate_mode = split_pandas_duplicate_suffix(raw_name)

        # Handles Mode1_Q_True, mode2_Gamma_Pred, 模式3_S3_Err, etc.
        match = re.match(r"^(?:Mode|mode|MODE|模式)\s*[_\- ]?([1-9]\d*)\s*[_\- ]+(.+)$", base_name)
        if match:
            return int(match.group(1)), match.group(2)

        # Handles Q_True_Mode1, Gamma_Pred_mode2, S3_Err_M3, etc.
        match = re.match(r"^(.+?)\s*[_\- ]+(?:Mode|mode|MODE|M|m|模式)\s*([1-9]\d*)$", base_name)
        if match:
            return int(match.group(2)), match.group(1)

        # Handles RealFreq_2, Real_0_1, ImagFreqPred_4, etc.
        # Avoid treating the common metric name S3 itself as mode 3.
        match = re.match(r"^(.+?)_([1-9]\d*)$", base_name)
        if match and match.group(1).strip().lower() != "s":
            return int(match.group(2)), match.group(1)

        # If the same header appears in each mode block, pandas' .1/.2/.3 gives the mode number.
        # The first occurrence has no suffix and is Mode 1.
        return duplicate_mode if duplicate_mode is not None else 1, base_name

    def normalize_token(text: object) -> str:
        return re.sub(r"[^a-z0-9]+", "", str(text).lower())

    def split_base_and_kind(metric_name: object) -> tuple[str, str | None]:
        """Split a metric column into base parameter name and value kind: true/pred/err."""
        name = clean_name(metric_name)
        name = split_pandas_duplicate_suffix(name)[0]
        parts = [p for p in re.split(r"[_\-\s]+", name) if p]
        kind_aliases = {
            "true": {"true", "truth", "target", "label", "actual", "gt", "ytrue"},
            "pred": {"pred", "predict", "predicted", "prediction", "output", "ypred"},
            "err": {"err", "error", "errors", "diff", "residual", "res", "delta", "abs_err", "abserr"},
        }
        if parts:
            last_norm = normalize_token(parts[-1])
            for kind, aliases in kind_aliases.items():
                if last_norm in {normalize_token(a) for a in aliases}:
                    return "_".join(parts[:-1]) if len(parts) > 1 else name, kind

        compact = normalize_token(name)
        suffix_patterns = [
            ("true", r"(.+?)(?:true|truth|target|label|actual|gt|ytrue)$"),
            ("pred", r"(.+?)(?:pred|predict|predicted|prediction|output|ypred)$"),
            ("err", r"(.+?)(?:err|error|errors|diff|residual|res|delta|abserr)$"),
        ]
        for kind, pattern in suffix_patterns:
            match = re.match(pattern, compact)
            if match and match.group(1):
                return match.group(1), kind
        return name, None

    def canonical_parameter(base_name: object) -> str | None:
        """Map different column names to the five requested output parameters."""
        norm = normalize_token(base_name)
        if not norm:
            return None

        # freq real part / frequency real part
        if (
            "realfreq" in norm
            or "freqreal" in norm
            or "realfrequency" in norm
            or "frequencyreal" in norm
            or ("freq" in norm and ("real" in norm or norm.endswith("re")))
        ):
            return "Freq_Real"

        # freq imaginary part / frequency imaginary part
        if (
            "imagfreq" in norm
            or "freqimag" in norm
            or "imaginaryfreq" in norm
            or "frequencyimag" in norm
            or ("freq" in norm and ("imag" in norm or norm.endswith("im")))
        ):
            return "Freq_Imag"

        if norm in {"q", "quality", "qualityfactor", "qfactor"} or norm.endswith("qfactor"):
            return "Q"

        if "s3" in norm or norm in {"siii", "sparameter3"}:
            return "S3"

        if "gamma" in norm or norm in {"gam", "gm"}:
            return "Gamma"

        return None

    def build_column_mapping(integrated_df: pd.DataFrame) -> dict[str, dict[str, object]]:
        mapping: dict[str, dict[str, object]] = OrderedDict(
            (key, {}) for key in ["Freq_Real", "Freq_Imag", "Q", "S3", "Gamma"]
        )
        id_names = {"t_t", "kx", "ky", "mode"}
        for col in integrated_df.columns:
            if clean_name(col).lower() in id_names:
                continue
            base_name, kind = split_base_and_kind(col)
            param = canonical_parameter(base_name)
            if param is None or kind is None:
                continue
            # Keep the first matching True/Pred/Err column for each requested parameter.
            mapping[param].setdefault(kind, col)
        return mapping

    def compute_metric_rows(integrated_df: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
        display_names = OrderedDict(
            [
                ("Freq_Real", "Freq real part / freq实部"),
                ("Freq_Imag", "Freq imaginary part / freq虚部"),
                ("Q", "Q"),
                ("S3", "S3"),
                ("Gamma", "Gamma / gamma"),
            ]
        )
        mapping = build_column_mapping(integrated_df)

        def calc_for_subset(subset: pd.DataFrame, param_key: str) -> dict[str, object]:
            cols = mapping.get(param_key, {})
            true_col = cols.get("true")
            pred_col = cols.get("pred")
            err_col = cols.get("err")

            if true_col is not None and pred_col is not None:
                true_values = pd.to_numeric(subset[true_col], errors="coerce")
                pred_values = pd.to_numeric(subset[pred_col], errors="coerce")
                err_values = pred_values - true_values
                source = "Pred - True"
            elif err_col is not None:
                err_values = pd.to_numeric(subset[err_col], errors="coerce")
                source = "Err column"
            else:
                return {
                    "N": 0,
                    "MSE": math.nan,
                    "MAE": math.nan,
                    "Error_Source": "missing True/Pred or Err columns",
                }

            err_values = err_values.dropna()
            if err_values.empty:
                return {"N": 0, "MSE": math.nan, "MAE": math.nan, "Error_Source": source}
            return {
                "N": int(err_values.shape[0]),
                "MSE": float((err_values ** 2).mean()),
                "MAE": float(err_values.abs().mean()),
                "Error_Source": source,
            }

        overall_rows = []
        for param_key, display_name in display_names.items():
            row = {"Parameter": display_name, "Parameter_Key": param_key}
            row.update(calc_for_subset(integrated_df, param_key))
            overall_rows.append(row)

        per_mode_rows = []
        if "Mode" in integrated_df.columns:
            mode_values = sorted(pd.Series(integrated_df["Mode"]).dropna().unique())
            for mode in mode_values:
                mode_df = integrated_df.loc[integrated_df["Mode"] == mode]
                for param_key, display_name in display_names.items():
                    row = {"Mode": mode, "Parameter": display_name, "Parameter_Key": param_key}
                    row.update(calc_for_subset(mode_df, param_key))
                    per_mode_rows.append(row)

        mapping_rows = []
        for param_key, display_name in display_names.items():
            cols = mapping.get(param_key, {})
            mapping_rows.append(
                {
                    "Parameter": display_name,
                    "Parameter_Key": param_key,
                    "True_Column": cols.get("true", ""),
                    "Pred_Column": cols.get("pred", ""),
                    "Err_Column": cols.get("err", ""),
                }
            )

        return pd.DataFrame(overall_rows), pd.DataFrame(per_mode_rows), pd.DataFrame(mapping_rows)

    def write_metrics_excel(integrated_df: pd.DataFrame) -> None:
        metrics_path = os.path.join(analysis_dir, "Validation_MSE_MAE_By_Param.xlsx")
        overall_df, per_mode_df, mapping_df = compute_metric_rows(integrated_df)

        with pd.ExcelWriter(metrics_path, engine="openpyxl") as writer:
            overall_df.to_excel(writer, sheet_name="Overall_All_Modes", index=False)
            per_mode_df.to_excel(writer, sheet_name="Per_Mode", index=False)
            mapping_df.to_excel(writer, sheet_name="Column_Mapping", index=False)

            workbook = writer.book
            for sheet_name in writer.sheets:
                worksheet = writer.sheets[sheet_name]
                worksheet.freeze_panes = "A2"
                for row in worksheet.iter_rows(min_row=1, max_row=1):
                    for cell in row:
                        cell.style = "Headline 4"
                for column_cells in worksheet.columns:
                    max_len = max(len(str(cell.value)) if cell.value is not None else 0 for cell in column_cells)
                    adjusted_width = min(max(max_len + 2, 12), 36)
                    worksheet.column_dimensions[column_cells[0].column_letter].width = adjusted_width
                for col_name in ["MSE", "MAE"]:
                    if col_name in [cell.value for cell in worksheet[1]]:
                        col_idx = [cell.value for cell in worksheet[1]].index(col_name) + 1
                        for cell in worksheet.iter_cols(min_col=col_idx, max_col=col_idx, min_row=2):
                            for c in cell:
                                c.number_format = "0.000000E+00"

        print(f"[OK] Wrote validation MSE/MAE summary: {metrics_path}")

    # Prefer the already-integrated sheet if this script is re-run on a previously post-processed file.
    xl = pd.ExcelFile(excel_path)
    if "Integrated_All_Modes" in xl.sheet_names:
        integrated_df = pd.read_excel(excel_path, sheet_name="Integrated_All_Modes")
        if integrated_df.empty:
            print(f"[WARN] Integrated_All_Modes in {excel_path} is empty; skip metric summary.")
            return
        if "Original_Wide" in xl.sheet_names:
            original_df = pd.read_excel(excel_path, sheet_name="Original_Wide")
        else:
            original_df = integrated_df.copy()
        write_metrics_excel(integrated_df)
        print(f"[OK] Existing integrated table found in {excel_path}; refreshed MSE/MAE summary.")
        return

    df = pd.read_excel(excel_path, sheet_name=0)
    if df.empty:
        print(f"[WARN] {excel_path} is empty; skip integrated Excel post-process and metric summary.")
        return

    # If the analyzer already wrote a long table, only create the metric summary.
    if "Mode" in [clean_name(c) for c in df.columns]:
        write_metrics_excel(df)
        print(f"[OK] Long-format validation table found in {excel_path}; wrote MSE/MAE summary only.")
        return

    column_names = list(df.columns)
    preferred_id_names = ["t_t", "kx", "ky"]
    id_columns: list[object] = []
    for wanted in preferred_id_names:
        for col in column_names:
            if clean_name(col) == wanted and col not in id_columns:
                id_columns.append(col)
                break
    if len(id_columns) != 3:
        id_columns = column_names[:3]

    id_set = set(id_columns)
    mode_to_columns: dict[int, dict[str, object]] = OrderedDict()
    metric_order: list[str] = []

    for col in column_names:
        if col in id_set:
            continue
        mode_id, metric_name = parse_mode_and_metric(col)
        if metric_name in preferred_id_names or metric_name.lower().startswith("unnamed"):
            continue
        mode_to_columns.setdefault(mode_id, OrderedDict())[metric_name] = col
        if metric_name not in metric_order:
            metric_order.append(metric_name)

    if len(mode_to_columns) <= 1:
        print(f"[WARN] Only found {len(mode_to_columns)} mode block in {excel_path}; keep the file unchanged.")
        write_metrics_excel(df)
        return

    integrated_parts = []
    for mode_id in sorted(mode_to_columns):
        source_columns = mode_to_columns[mode_id]
        part = df.loc[:, id_columns].copy()
        part.insert(len(id_columns), "Mode", mode_id)
        for metric_name in metric_order:
            source_col = source_columns.get(metric_name)
            part[metric_name] = df[source_col] if source_col is not None else pd.NA
        integrated_parts.append(part)

    integrated_df = pd.concat(integrated_parts, ignore_index=True)

    # Keep the original wide-format table as the second sheet, while making the first sheet easy to plot.
    with pd.ExcelWriter(excel_path, engine="openpyxl") as writer:
        integrated_df.to_excel(writer, sheet_name="Integrated_All_Modes", index=False)
        df.to_excel(writer, sheet_name="Original_Wide", index=False)

    print(
        f"[OK] Integrated four-mode results in {excel_path}: "
        f"{len(df)} original rows -> {len(integrated_df)} integrated rows."
    )

    write_metrics_excel(integrated_df)


def default_config() -> BaselineConfig:
    return BaselineConfig(
        model_name="MLP",
        model_dir=os.path.join(CURRENT_DIR, "Phase1_MLP_Models_RawModes"),
        analysis_dir=os.path.join(CURRENT_DIR, "Phase2_MLP_Analysis_RawModes"),
        hidden_dim=128,
        num_layers=4,
        dropout=0.05,
    )


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Plot validation diagnostics for the plain MLP baseline.")
    add_plot_args(parser)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    cfg = apply_args_to_config(default_config(), args, phase="plot")
    analyze_baseline("mlp", cfg, args.csv)
    _integrate_validation_predictions_excel(cfg.analysis_dir)


if __name__ == "__main__":
    main()
