# -*- coding: utf-8 -*-
"""Phase 1: train a plain MLP baseline on raw CSV mode order."""

from __future__ import annotations

import argparse
import os
import sys


CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
COMPARE_ROOT = os.path.dirname(CURRENT_DIR)
if COMPARE_ROOT not in sys.path:
    sys.path.insert(0, COMPARE_ROOT)

from baseline_common import BaselineConfig, add_train_args, apply_args_to_config, train_baseline


def default_config() -> BaselineConfig:
    return BaselineConfig(
        model_name="MLP",
        model_dir=os.path.join(CURRENT_DIR, "Phase1_MLP_Models_RawModes"),
        analysis_dir=os.path.join(CURRENT_DIR, "Phase2_MLP_Analysis_RawModes"),
        epochs=300,
        learning_rate=1e-3,
        weight_decay=1e-5,
        hidden_dim=128,
        num_layers=4,
        dropout=0.05,
        early_stop_patience=60,
    )


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Train a plain MLP baseline without mode tracking.")
    add_train_args(parser)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    cfg = apply_args_to_config(default_config(), args, phase="train")
    train_baseline("mlp", cfg, args.csv)


if __name__ == "__main__":
    main()
