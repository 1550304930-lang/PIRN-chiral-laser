# -*- coding: utf-8 -*-
"""Phase 2: plot validation diagnostics for the plain MLP baseline."""

from __future__ import annotations

import argparse
import os
import sys


CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
COMPARE_ROOT = os.path.dirname(CURRENT_DIR)
if COMPARE_ROOT not in sys.path:
    sys.path.insert(0, COMPARE_ROOT)

from baseline_common import BaselineConfig, add_plot_args, analyze_baseline, apply_args_to_config


def _integrate_validation_predictions_excel(analysis_dir: str) -> None:
    """Convert Validation_Predictions_All_Params.xlsx from wide mode blocks to long mode-integrated columns.

    The original analyzer writes the four modes side by side, for example:
    RealFreq_True, RealFreq_Pred, ... Mode1_Q_True, ... RealFreq_True.1, ... Mode2_Q_True, ...

    This post-processes the file to a plotting-friendly long table:
    t_t, kx, ky, Mode, RealFreq_True, RealFreq_Pred, ..., Q_True, ...
    where the values from Mode 1-4 are stacked into the same result-parameter columns.
    """
    import re
    from collections import OrderedDict

    import pandas as pd

    excel_path = os.path.join(analysis_dir, "Validation_Predictions_All_Params.xlsx")
    if not os.path.exists(excel_path):
        print(f"[WARN] Cannot find {excel_path}; skip integrated Excel post-process.")
        return

    df = pd.read_excel(excel_path, sheet_name=0)
    if df.empty:
        print(f"[WARN] {excel_path} is empty; skip integrated Excel post-process.")
        return

    def clean_name(name: object) -> str:
        return str(name).strip()

    def split_pandas_duplicate_suffix(name: str) -> tuple[str, int | None]:
        """Pandas renames duplicate Excel headers as name, name.1, name.2, ..."""
        match = re.match(r"^(.*)\.(\d+)$", name)
        if match:
            return match.group(1), int(match.group(2)) + 1
        return name, None

    def parse_mode_and_metric(name: object) -> tuple[int, str]:
        """Return (mode_id, mode-independent_metric_name)."""
        raw_name = clean_name(name)
        base_name, duplicate_mode = split_pandas_duplicate_suffix(raw_name)

        # Handles Mode1_Q_True, mode2_Gamma_Pred, 模式3_S3_Err, etc.
        match = re.match(r"^(?:Mode|mode|MODE|模式)\s*[_\- ]?([1-9]\d*)\s*[_\- ]+(.+)$", base_name)
        if match:
            return int(match.group(1)), match.group(2)

        # Handles Q_True_Mode1, Gamma_Pred_mode2, S3_Err_M3, etc.
        match = re.match(r"^(.+?)\s*[_\- ]+(?:Mode|mode|MODE|M|m|模式)\s*([1-9]\d*)$", base_name)
        if match:
            return int(match.group(2)), match.group(1)

        # Handles RealFreq_2, Real_0_1, ImagFreqPred_4, etc.
        # Avoid treating the common metric name S3 itself as mode 3.
        match = re.match(r"^(.+?)_([1-9]\d*)$", base_name)
        if match and match.group(1).strip().lower() != "s":
            return int(match.group(2)), match.group(1)

        # If the same header appears in each mode block, pandas' .1/.2/.3 gives the mode number.
        # The first occurrence has no suffix and is Mode 1.
        return duplicate_mode if duplicate_mode is not None else 1, base_name

    column_names = list(df.columns)
    preferred_id_names = ["t_t", "kx", "ky"]
    id_columns: list[object] = []
    for wanted in preferred_id_names:
        for col in column_names:
            if clean_name(col) == wanted and col not in id_columns:
                id_columns.append(col)
                break
    if len(id_columns) != 3:
        id_columns = column_names[:3]

    id_set = set(id_columns)
    mode_to_columns: dict[int, dict[str, object]] = OrderedDict()
    metric_order: list[str] = []

    for col in column_names:
        if col in id_set:
            continue
        mode_id, metric_name = parse_mode_and_metric(col)
        if metric_name in preferred_id_names or metric_name.lower().startswith("unnamed"):
            continue
        mode_to_columns.setdefault(mode_id, OrderedDict())[metric_name] = col
        if metric_name not in metric_order:
            metric_order.append(metric_name)

    if len(mode_to_columns) <= 1:
        print(f"[WARN] Only found {len(mode_to_columns)} mode block in {excel_path}; keep the file unchanged.")
        return

    integrated_parts = []
    for mode_id in sorted(mode_to_columns):
        source_columns = mode_to_columns[mode_id]
        part = df.loc[:, id_columns].copy()
        part.insert(len(id_columns), "Mode", mode_id)
        for metric_name in metric_order:
            source_col = source_columns.get(metric_name)
            part[metric_name] = df[source_col] if source_col is not None else pd.NA
        integrated_parts.append(part)

    integrated_df = pd.concat(integrated_parts, ignore_index=True)

    # Keep the original wide-format table as the second sheet, while making the first sheet easy to plot.
    with pd.ExcelWriter(excel_path, engine="openpyxl") as writer:
        integrated_df.to_excel(writer, sheet_name="Integrated_All_Modes", index=False)
        df.to_excel(writer, sheet_name="Original_Wide", index=False)

    print(
        f"[OK] Integrated four-mode results in {excel_path}: "
        f"{len(df)} original rows -> {len(integrated_df)} integrated rows."
    )


def default_config() -> BaselineConfig:
    return BaselineConfig(
        model_name="MLP",
        model_dir=os.path.join(CURRENT_DIR, "Phase1_MLP_Models_RawModes"),
        analysis_dir=os.path.join(CURRENT_DIR, "Phase2_MLP_Analysis_RawModes"),
        hidden_dim=128,
        num_layers=4,
        dropout=0.05,
    )


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Plot validation diagnostics for the plain MLP baseline.")
    add_plot_args(parser)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    cfg = apply_args_to_config(default_config(), args, phase="plot")
    analyze_baseline("mlp", cfg, args.csv)
    _integrate_validation_predictions_excel(cfg.analysis_dir)


if __name__ == "__main__":
    main()
