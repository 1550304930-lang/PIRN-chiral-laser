# -*- coding: utf-8 -*-
"""
Shared utilities for raw-mode baseline experiments.

These baselines intentionally avoid the PINN workflow's mode tracking, physics
losses, Fourier feature map, and focus-weighted loss. They keep only the basic
CSV parsing, normalization, t_t group split, model training, and validation
plotting needed for transparent comparison experiments.
"""

from __future__ import annotations

import argparse
import glob
import json
import math
import os
import random
from dataclasses import asdict, dataclass, fields
from typing import Dict, List, Optional, Sequence, Tuple

import matplotlib

matplotlib.use("Agg")

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.optim as optim
from matplotlib.patches import FancyBboxPatch
from torch.utils.data import DataLoader, TensorDataset


N_MODES = 4
N_PARAMS_PER_MODE = 5
OUTPUT_DIM = N_MODES * N_PARAMS_PER_MODE
PARAM_NAMES = ["RealFreq", "ImagFreq", "Q", "Gamma", "S3"]
PLOT_PARAM_NAMES = ["Real Freq (THz)", "Imag Freq (THz)", "Q Factor", "Gamma Factor", "S3 Parameter"]
MAIN_PARAMS = [0, 1, 4]


@dataclass
class BaselineConfig:
    model_name: str
    model_dir: str
    analysis_dir: str
    split_mode: str = "group_t"
    val_ratio: float = 0.2
    seed: int = 42
    batch_size: int = 8192
    epochs: int = 300
    learning_rate: float = 1e-3
    weight_decay: float = 1e-5
    hidden_dim: int = 128
    num_layers: int = 4
    dropout: float = 0.05
    early_stop_patience: int = 60
    scheduler_patience: int = 20
    latent_dim: int = 8
    adv_weight: float = 0.02
    discriminator_lr: float = 5e-4
    reference_pinn_model_dir: Optional[str] = None
    use_reference_split: bool = True


def repo_paths() -> Tuple[str, str, str]:
    compare_root = os.path.dirname(os.path.abspath(__file__))
    algorithm_root = os.path.dirname(compare_root)
    pinn_root = os.path.join(algorithm_root, "PIRNN")
    return compare_root, algorithm_root, pinn_root


def default_csv_path() -> Optional[str]:
    compare_root, _, pinn_root = repo_paths()
    candidates: List[str] = []
    candidates.extend(sorted(glob.glob(os.path.join(os.getcwd(), "*GaAs.csv"))))
    candidates.extend(sorted(glob.glob(os.path.join(pinn_root, "*GaAs.csv"))))
    candidates.extend(sorted(glob.glob(os.path.join(compare_root, "*GaAs.csv"))))
    return candidates[0] if candidates else None


def default_pinn_model_dir() -> str:
    _, _, pinn_root = repo_paths()
    return os.path.join(pinn_root, "Phase1_PINN_Models_GroupSplit_Improved")


def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def find_csv_path(csv_path: Optional[str] = None) -> str:
    if csv_path is not None and os.path.exists(csv_path):
        return csv_path
    found = default_csv_path()
    if found is not None and os.path.exists(found):
        return found
    raise FileNotFoundError("No GaAs CSV was found. Pass --csv explicitly.")


def read_comsol_csv(csv_path: str) -> pd.DataFrame:
    print(f"Loading COMSOL CSV: {csv_path}")
    last_error: Optional[Exception] = None
    for encoding in ("gbk", "gb18030", "utf-8-sig", "utf-8"):
        try:
            df = pd.read_csv(csv_path, encoding=encoding, skiprows=4)
            break
        except Exception as exc:
            last_error = exc
    else:
        raise RuntimeError(f"Could not read CSV with common encodings: {last_error}")

    df[df.columns[0]] = pd.to_numeric(df[df.columns[0]], errors="coerce")
    df = df.dropna(subset=[df.columns[0]]).reset_index(drop=True)
    return df


def safe_complex_array(values: np.ndarray) -> np.ndarray:
    out: List[complex] = []
    for value in values.astype(str):
        text = value.replace("i", "j").replace(" ", "")
        try:
            out.append(complex(text))
        except Exception:
            out.append(np.nan + 1j * np.nan)
    return np.asarray(out, dtype=np.complex128)


def extract_raw_modes(df: pd.DataFrame) -> Tuple[np.ndarray, np.ndarray]:
    x = df.iloc[:, :3].values.astype(np.float32)
    y_modes = np.zeros((len(df), N_MODES, N_PARAMS_PER_MODE), dtype=np.float32)

    for mode_idx in range(N_MODES):
        base_col = 3 + mode_idx * 7
        freq_complex = safe_complex_array(df.iloc[:, base_col + 3].astype(str).values)
        y_modes[:, mode_idx, 0] = np.nan_to_num(freq_complex.real, nan=0.0)
        y_modes[:, mode_idx, 1] = np.nan_to_num(freq_complex.imag, nan=0.0)
        y_modes[:, mode_idx, 2] = pd.to_numeric(df.iloc[:, base_col + 4], errors="coerce").fillna(0).values.astype(np.float32)
        y_modes[:, mode_idx, 3] = pd.to_numeric(df.iloc[:, base_col + 5], errors="coerce").fillna(0).values.astype(np.float32)
        y_modes[:, mode_idx, 4] = pd.to_numeric(df.iloc[:, base_col + 6], errors="coerce").fillna(0).values.astype(np.float32)

    return x, y_modes


def flatten_modes(y_modes: np.ndarray) -> np.ndarray:
    y = np.zeros((y_modes.shape[0], OUTPUT_DIM), dtype=np.float32)
    for mode_idx in range(N_MODES):
        start = mode_idx * N_PARAMS_PER_MODE
        y[:, start : start + N_PARAMS_PER_MODE] = y_modes[:, mode_idx, :]
    return y


def unflatten_modes(y: np.ndarray) -> np.ndarray:
    return y.reshape(y.shape[0], N_MODES, N_PARAMS_PER_MODE)


def load_raw_data(csv_path: str) -> Tuple[np.ndarray, np.ndarray]:
    df = read_comsol_csv(csv_path)
    x, y_modes = extract_raw_modes(df)
    print("Using raw mode order from the CSV; no mode tracking or mode alignment is applied.")
    return x, flatten_modes(y_modes)


def round_keys(values: np.ndarray, decimals: int = 10) -> np.ndarray:
    return np.round(values.astype(np.float64), decimals)


def choose_even_validation_t(unique_t: np.ndarray, val_ratio: float) -> np.ndarray:
    n_val = max(1, int(round(len(unique_t) * val_ratio)))
    if len(unique_t) <= n_val:
        return unique_t.copy()

    left = 1 if len(unique_t) > 4 else 0
    right = len(unique_t) - 2 if len(unique_t) > 4 else len(unique_t) - 1
    positions = np.rint(np.linspace(left, right, n_val)).astype(int)
    positions = np.unique(positions)
    while len(positions) < n_val:
        for pos in range(left, right + 1):
            if pos not in positions:
                positions = np.sort(np.append(positions, pos))
                break
    return unique_t[positions[:n_val]]


def load_reference_val_t_values(reference_model_dir: Optional[str]) -> Optional[np.ndarray]:
    if reference_model_dir is None:
        reference_model_dir = default_pinn_model_dir()
    meta_path = os.path.join(reference_model_dir, "pinn_metadata.npz")
    if os.path.exists(meta_path):
        meta = np.load(meta_path, allow_pickle=True)
        if "val_t_values" in meta.files:
            values = np.asarray(meta["val_t_values"], dtype=np.float64)
            if len(values):
                print(f"Using reference validation t_t values from: {meta_path}")
                return values

    csv_path = os.path.join(reference_model_dir, "Validation_t_values.csv")
    if os.path.exists(csv_path):
        df = pd.read_csv(csv_path)
        first_col = df.columns[0]
        values = pd.to_numeric(df[first_col], errors="coerce").dropna().to_numpy(dtype=np.float64)
        if len(values):
            print(f"Using reference validation t_t values from: {csv_path}")
            return values
    return None


def make_train_val_split(
    x: np.ndarray,
    cfg: BaselineConfig,
    output_dir: str,
    val_t_values: Optional[Sequence[float]] = None,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray, str]:
    t_keys = round_keys(x[:, 0])
    unique_t = np.sort(np.unique(t_keys))
    split_source = "generated"

    if cfg.split_mode == "group_t":
        if val_t_values is None or len(val_t_values) == 0:
            val_t_keys = choose_even_validation_t(unique_t, cfg.val_ratio)
        else:
            val_t_keys = round_keys(np.asarray(val_t_values, dtype=np.float64))
            split_source = "reference"
        val_mask = np.isin(t_keys, val_t_keys)
        train_idx = np.where(~val_mask)[0]
        val_idx = np.where(val_mask)[0]
    elif cfg.split_mode == "random":
        indices = np.arange(len(x))
        rng = np.random.default_rng(cfg.seed)
        rng.shuffle(indices)
        split = int(len(indices) * (1.0 - cfg.val_ratio))
        train_idx = indices[:split]
        val_idx = indices[split:]
        val_t_keys = np.sort(np.unique(t_keys[val_idx]))
        split_source = "random"
    else:
        raise ValueError(f"Unsupported split_mode: {cfg.split_mode}")

    if len(train_idx) == 0 or len(val_idx) == 0:
        raise RuntimeError("The train/validation split produced an empty split.")

    os.makedirs(output_dir, exist_ok=True)
    split_rows = []
    val_set = set(val_t_keys.tolist())
    for t_key in unique_t:
        mask = t_keys == t_key
        split_rows.append(
            {
                "t_t": float(t_key),
                "rows": int(np.sum(mask)),
                "split": "val" if float(t_key) in val_set else "train",
            }
        )
    pd.DataFrame(split_rows).to_csv(os.path.join(output_dir, "Group_Split_Summary.csv"), index=False, encoding="utf-8-sig")
    pd.DataFrame({"val_t_t": val_t_keys}).to_csv(os.path.join(output_dir, "Validation_t_values.csv"), index=False)

    print(f"Split mode: {cfg.split_mode} ({split_source})")
    print(f"Train rows={len(train_idx)}, val rows={len(val_idx)}")
    print(f"Held-out t_t values: {np.array2string(val_t_keys, precision=5)}")
    return train_idx, val_idx, val_t_keys, split_source


class BaselineMLP(nn.Module):
    def __init__(self, input_dim: int = 3, hidden_dim: int = 128, num_layers: int = 4, dropout: float = 0.05):
        super().__init__()
        layers: List[nn.Module] = []
        in_dim = input_dim
        for _ in range(max(1, num_layers)):
            layers.extend([nn.Linear(in_dim, hidden_dim), nn.ReLU()])
            if dropout > 0:
                layers.append(nn.Dropout(dropout))
            in_dim = hidden_dim
        layers.append(nn.Linear(in_dim, OUTPUT_DIM))
        self.net = nn.Sequential(*layers)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x)


class BaselineCNN1D(nn.Module):
    def __init__(self, hidden_dim: int = 96, dropout: float = 0.05):
        super().__init__()
        self.conv = nn.Sequential(
            nn.Conv1d(1, 16, kernel_size=2, padding=1),
            nn.ReLU(),
            nn.Conv1d(16, 32, kernel_size=2, padding=1),
            nn.ReLU(),
            nn.AdaptiveAvgPool1d(1),
        )
        self.head = nn.Sequential(
            nn.Flatten(),
            nn.Linear(32, hidden_dim),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, OUTPUT_DIM),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.head(self.conv(x.unsqueeze(1)))


class ConditionalGenerator(nn.Module):
    def __init__(self, input_dim: int = 3, latent_dim: int = 8, hidden_dim: int = 128, num_layers: int = 3, dropout: float = 0.05):
        super().__init__()
        layers: List[nn.Module] = []
        in_dim = input_dim + latent_dim
        for _ in range(max(1, num_layers)):
            layers.extend([nn.Linear(in_dim, hidden_dim), nn.LeakyReLU(0.2)])
            if dropout > 0:
                layers.append(nn.Dropout(dropout))
            in_dim = hidden_dim
        layers.append(nn.Linear(in_dim, OUTPUT_DIM))
        self.net = nn.Sequential(*layers)
        self.latent_dim = latent_dim

    def forward(self, x: torch.Tensor, z: Optional[torch.Tensor] = None) -> torch.Tensor:
        if z is None:
            z = torch.zeros((x.shape[0], self.latent_dim), dtype=x.dtype, device=x.device)
        return self.net(torch.cat([x, z], dim=1))


class ConditionalDiscriminator(nn.Module):
    def __init__(self, input_dim: int = 3, hidden_dim: int = 128, num_layers: int = 3, dropout: float = 0.05):
        super().__init__()
        layers: List[nn.Module] = []
        in_dim = input_dim + OUTPUT_DIM
        for _ in range(max(1, num_layers)):
            layers.extend([nn.Linear(in_dim, hidden_dim), nn.LeakyReLU(0.2)])
            if dropout > 0:
                layers.append(nn.Dropout(dropout))
            in_dim = hidden_dim
        layers.append(nn.Linear(in_dim, 1))
        self.net = nn.Sequential(*layers)

    def forward(self, x: torch.Tensor, y: torch.Tensor) -> torch.Tensor:
        return self.net(torch.cat([x, y], dim=1)).squeeze(-1)


def make_model(model_kind: str, cfg: BaselineConfig) -> nn.Module:
    if model_kind == "mlp":
        return BaselineMLP(hidden_dim=cfg.hidden_dim, num_layers=cfg.num_layers, dropout=cfg.dropout)
    if model_kind == "cnn":
        return BaselineCNN1D(hidden_dim=cfg.hidden_dim, dropout=cfg.dropout)
    if model_kind == "gan_generator":
        return ConditionalGenerator(latent_dim=cfg.latent_dim, hidden_dim=cfg.hidden_dim, num_layers=cfg.num_layers, dropout=cfg.dropout)
    if model_kind == "gan_discriminator":
        return ConditionalDiscriminator(hidden_dim=cfg.hidden_dim, num_layers=cfg.num_layers, dropout=cfg.dropout)
    raise ValueError(f"Unsupported model kind: {model_kind}")


def make_loader(
    x_norm: np.ndarray,
    y_norm: np.ndarray,
    indices: np.ndarray,
    batch_size: int,
    shuffle: bool,
    device: torch.device,
) -> DataLoader:
    dataset = TensorDataset(
        torch.tensor(x_norm[indices], dtype=torch.float32),
        torch.tensor(y_norm[indices], dtype=torch.float32),
    )
    return DataLoader(dataset, batch_size=batch_size, shuffle=shuffle, pin_memory=device.type == "cuda")


def focus_column_groups() -> Dict[str, List[int]]:
    return {
        "RealFreq": [mode_idx * N_PARAMS_PER_MODE for mode_idx in range(N_MODES)],
        "ImagFreq": [mode_idx * N_PARAMS_PER_MODE + 1 for mode_idx in range(N_MODES)],
        "S3": [mode_idx * N_PARAMS_PER_MODE + 4 for mode_idx in range(N_MODES)],
    }


def evaluate_from_loader(
    model: nn.Module,
    loader: DataLoader,
    device: torch.device,
    y_mean: torch.Tensor,
    y_std: torch.Tensor,
    model_kind: str,
    latent_dim: int,
) -> Dict[str, float]:
    model.eval()
    norm_mse_sum = 0.0
    rows = 0
    focus_abs = {key: 0.0 for key in focus_column_groups()}
    focus_cols = {key: torch.tensor(cols, dtype=torch.long, device=device) for key, cols in focus_column_groups().items()}

    with torch.no_grad():
        for batch_x, batch_y in loader:
            batch_x = batch_x.to(device, non_blocking=True)
            batch_y = batch_y.to(device, non_blocking=True)
            if model_kind == "gan":
                pred_norm = model(batch_x, torch.zeros((len(batch_x), latent_dim), dtype=torch.float32, device=device))
            else:
                pred_norm = model(batch_x)
            norm_mse_sum += float(torch.mean((pred_norm - batch_y) ** 2).item()) * len(batch_x)
            pred = pred_norm * y_std + y_mean
            true = batch_y * y_std + y_mean
            rows += len(batch_x)
            for key, cols in focus_cols.items():
                focus_abs[key] += float(torch.sum(torch.abs(pred[:, cols] - true[:, cols])).item())

    denom = max(rows * N_MODES, 1)
    return {
        "val_norm_mse": norm_mse_sum / max(rows, 1),
        "val_real_mae": focus_abs["RealFreq"] / denom,
        "val_imag_mae": focus_abs["ImagFreq"] / denom,
        "val_s3_mae": focus_abs["S3"] / denom,
    }


def save_training_outputs(history: pd.DataFrame, cfg: BaselineConfig) -> None:
    os.makedirs(cfg.model_dir, exist_ok=True)
    history.to_excel(os.path.join(cfg.model_dir, "Training_History_Full.xlsx"), index=False)

    fig, ax = plt.subplots(figsize=(8.2, 5.2))
    for col, label in [
        ("Train_Loss", "Train loss"),
        ("Train_G_Loss", "Generator loss"),
        ("Train_D_Loss", "Discriminator loss"),
        ("Train_Supervised_MSE", "Supervised MSE"),
        ("Val_Norm_MSE", "Val normalized MSE"),
    ]:
        if col in history.columns:
            ax.plot(history["Epoch"], history[col], label=label, linewidth=1.6)
    ax.set_yscale("log")
    ax.set_xlabel("Epoch")
    ax.set_ylabel("Loss")
    ax.set_title(f"{cfg.model_name} Training Loss")
    ax.grid(True, linestyle=":", alpha=0.55)
    ax.legend()
    fig.tight_layout()
    fig.savefig(os.path.join(cfg.model_dir, "Loss_History.png"), dpi=300, bbox_inches="tight")
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(8.2, 5.2))
    ax.plot(history["Epoch"], history["Val_Real_MAE"], label="Real MAE", linewidth=1.6)
    ax.plot(history["Epoch"], history["Val_Imag_MAE"], label="Imag MAE", linewidth=1.6)
    ax.plot(history["Epoch"], history["Val_S3_MAE"], label="S3 MAE", linewidth=1.6)
    ax.set_xlabel("Epoch")
    ax.set_ylabel("MAE")
    ax.set_title(f"{cfg.model_name} Validation Focus MAE")
    ax.grid(True, linestyle=":", alpha=0.55)
    ax.legend()
    fig.tight_layout()
    fig.savefig(os.path.join(cfg.model_dir, "Validation_Focus_MAE_History.png"), dpi=300, bbox_inches="tight")
    plt.close(fig)


def save_metadata(
    cfg: BaselineConfig,
    model_kind: str,
    x_mean: np.ndarray,
    x_std: np.ndarray,
    y_mean: np.ndarray,
    y_std: np.ndarray,
    val_t_values: np.ndarray,
    train_t_values: np.ndarray,
    best_epoch: int,
    best_val_mse: float,
    split_source: str,
) -> None:
    np.savez(
        os.path.join(cfg.model_dir, "baseline_metadata.npz"),
        X_mean=x_mean,
        X_std=x_std,
        Y_mean=y_mean,
        Y_std=y_std,
        val_t_values=val_t_values,
        train_t_values=train_t_values,
        split_mode=cfg.split_mode,
        split_source=split_source,
        model_kind=model_kind,
        best_epoch=best_epoch,
        best_val_norm_mse=best_val_mse,
        data_mode_order="raw_csv_order_no_tracking",
        config_json=json.dumps(asdict(cfg)),
    )
    with open(os.path.join(cfg.model_dir, "training_config.json"), "w", encoding="utf-8") as f:
        json.dump(asdict(cfg), f, indent=2)


def train_supervised_baseline(model_kind: str, cfg: BaselineConfig, train_loader: DataLoader, val_loader: DataLoader, tensors: Dict[str, torch.Tensor]) -> Tuple[int, float, List[Dict[str, float]]]:
    device = tensors["device"]
    model = make_model(model_kind, cfg).to(device)
    optimizer = optim.AdamW(model.parameters(), lr=cfg.learning_rate, weight_decay=cfg.weight_decay)
    scheduler = optim.lr_scheduler.ReduceLROnPlateau(optimizer, mode="min", patience=cfg.scheduler_patience, factor=0.5)
    mse_loss = nn.MSELoss()

    best_val = float("inf")
    best_epoch = -1
    no_improve = 0
    history_rows: List[Dict[str, float]] = []

    for epoch in range(1, cfg.epochs + 1):
        model.train()
        train_loss = 0.0
        batches = 0
        for batch_x, batch_y in train_loader:
            batch_x = batch_x.to(device, non_blocking=True)
            batch_y = batch_y.to(device, non_blocking=True)
            optimizer.zero_grad(set_to_none=True)
            pred = model(batch_x)
            loss = mse_loss(pred, batch_y)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=2.0)
            optimizer.step()
            train_loss += float(loss.detach().item())
            batches += 1

        val_metrics = evaluate_from_loader(model, val_loader, device, tensors["y_mean"], tensors["y_std"], model_kind="supervised", latent_dim=cfg.latent_dim)
        scheduler.step(val_metrics["val_norm_mse"])
        row = {
            "Epoch": epoch,
            "Train_Loss": train_loss / max(batches, 1),
            "Val_Norm_MSE": val_metrics["val_norm_mse"],
            "Val_Real_MAE": val_metrics["val_real_mae"],
            "Val_Imag_MAE": val_metrics["val_imag_mae"],
            "Val_S3_MAE": val_metrics["val_s3_mae"],
            "Learning_Rate": optimizer.param_groups[0]["lr"],
        }
        history_rows.append(row)

        improved = row["Val_Norm_MSE"] < best_val
        if improved:
            best_val = row["Val_Norm_MSE"]
            best_epoch = epoch
            no_improve = 0
            torch.save({"model_kind": model_kind, "model_state": model.state_dict(), "config": asdict(cfg)}, os.path.join(cfg.model_dir, "best_model.pth"))
        else:
            no_improve += 1

        if epoch == 1 or epoch % 10 == 0 or improved:
            print(
                f"Epoch {epoch:4d}/{cfg.epochs} | train={row['Train_Loss']:.4e} | "
                f"val_mse={row['Val_Norm_MSE']:.4e} | MAE real={row['Val_Real_MAE']:.4e} "
                f"imag={row['Val_Imag_MAE']:.4e} S3={row['Val_S3_MAE']:.4e}"
            )
        if no_improve >= cfg.early_stop_patience:
            print(f"Early stopping at epoch {epoch}; best epoch was {best_epoch}.")
            break

    return best_epoch, best_val, history_rows


def train_gan_baseline(cfg: BaselineConfig, train_loader: DataLoader, val_loader: DataLoader, tensors: Dict[str, torch.Tensor]) -> Tuple[int, float, List[Dict[str, float]]]:
    device = tensors["device"]
    generator = make_model("gan_generator", cfg).to(device)
    discriminator = make_model("gan_discriminator", cfg).to(device)
    opt_g = optim.AdamW(generator.parameters(), lr=cfg.learning_rate, weight_decay=cfg.weight_decay)
    opt_d = optim.AdamW(discriminator.parameters(), lr=cfg.discriminator_lr, weight_decay=cfg.weight_decay)
    scheduler = optim.lr_scheduler.ReduceLROnPlateau(opt_g, mode="min", patience=cfg.scheduler_patience, factor=0.5)
    mse_loss = nn.MSELoss()
    bce_loss = nn.BCEWithLogitsLoss()

    best_val = float("inf")
    best_epoch = -1
    no_improve = 0
    history_rows: List[Dict[str, float]] = []

    for epoch in range(1, cfg.epochs + 1):
        generator.train()
        discriminator.train()
        g_total = 0.0
        d_total = 0.0
        sup_total = 0.0
        adv_total = 0.0
        batches = 0

        for batch_x, batch_y in train_loader:
            batch_x = batch_x.to(device, non_blocking=True)
            batch_y = batch_y.to(device, non_blocking=True)
            real_label = torch.ones(len(batch_x), dtype=torch.float32, device=device)
            fake_label = torch.zeros(len(batch_x), dtype=torch.float32, device=device)

            opt_d.zero_grad(set_to_none=True)
            z = torch.randn((len(batch_x), cfg.latent_dim), dtype=torch.float32, device=device)
            fake_y = generator(batch_x, z).detach()
            real_logits = discriminator(batch_x, batch_y)
            fake_logits = discriminator(batch_x, fake_y)
            d_loss = 0.5 * (bce_loss(real_logits, real_label) + bce_loss(fake_logits, fake_label))
            d_loss.backward()
            torch.nn.utils.clip_grad_norm_(discriminator.parameters(), max_norm=2.0)
            opt_d.step()

            opt_g.zero_grad(set_to_none=True)
            z = torch.randn((len(batch_x), cfg.latent_dim), dtype=torch.float32, device=device)
            fake_y = generator(batch_x, z)
            sup_loss = mse_loss(fake_y, batch_y)
            adv_loss = bce_loss(discriminator(batch_x, fake_y), real_label)
            g_loss = sup_loss + cfg.adv_weight * adv_loss
            g_loss.backward()
            torch.nn.utils.clip_grad_norm_(generator.parameters(), max_norm=2.0)
            opt_g.step()

            g_total += float(g_loss.detach().item())
            d_total += float(d_loss.detach().item())
            sup_total += float(sup_loss.detach().item())
            adv_total += float(adv_loss.detach().item())
            batches += 1

        val_metrics = evaluate_from_loader(generator, val_loader, device, tensors["y_mean"], tensors["y_std"], model_kind="gan", latent_dim=cfg.latent_dim)
        scheduler.step(val_metrics["val_norm_mse"])
        row = {
            "Epoch": epoch,
            "Train_G_Loss": g_total / max(batches, 1),
            "Train_D_Loss": d_total / max(batches, 1),
            "Train_Supervised_MSE": sup_total / max(batches, 1),
            "Train_Adversarial_Loss": adv_total / max(batches, 1),
            "Val_Norm_MSE": val_metrics["val_norm_mse"],
            "Val_Real_MAE": val_metrics["val_real_mae"],
            "Val_Imag_MAE": val_metrics["val_imag_mae"],
            "Val_S3_MAE": val_metrics["val_s3_mae"],
            "Learning_Rate_G": opt_g.param_groups[0]["lr"],
            "Learning_Rate_D": opt_d.param_groups[0]["lr"],
        }
        history_rows.append(row)

        improved = row["Val_Norm_MSE"] < best_val
        if improved:
            best_val = row["Val_Norm_MSE"]
            best_epoch = epoch
            no_improve = 0
            torch.save(
                {
                    "model_kind": "gan",
                    "generator_state": generator.state_dict(),
                    "discriminator_state": discriminator.state_dict(),
                    "config": asdict(cfg),
                },
                os.path.join(cfg.model_dir, "best_model.pth"),
            )
        else:
            no_improve += 1

        if epoch == 1 or epoch % 10 == 0 or improved:
            print(
                f"Epoch {epoch:4d}/{cfg.epochs} | G={row['Train_G_Loss']:.4e} D={row['Train_D_Loss']:.4e} | "
                f"val_mse={row['Val_Norm_MSE']:.4e} | MAE real={row['Val_Real_MAE']:.4e} "
                f"imag={row['Val_Imag_MAE']:.4e} S3={row['Val_S3_MAE']:.4e}"
            )
        if no_improve >= cfg.early_stop_patience:
            print(f"Early stopping at epoch {epoch}; best epoch was {best_epoch}.")
            break

    return best_epoch, best_val, history_rows


def train_baseline(model_kind: str, cfg: BaselineConfig, csv_path: Optional[str] = None) -> None:
    set_seed(cfg.seed)
    csv_path = find_csv_path(csv_path)
    os.makedirs(cfg.model_dir, exist_ok=True)

    x_raw, y_raw = load_raw_data(csv_path)
    reference_values = None
    if cfg.use_reference_split and cfg.split_mode == "group_t":
        reference_values = load_reference_val_t_values(cfg.reference_pinn_model_dir)
    train_idx, val_idx, val_t_values, split_source = make_train_val_split(x_raw, cfg, cfg.model_dir, reference_values)

    x_mean = np.mean(x_raw[train_idx], axis=0)
    x_std = np.std(x_raw[train_idx], axis=0) + 1e-8
    y_mean = np.mean(y_raw[train_idx], axis=0)
    y_std = np.std(y_raw[train_idx], axis=0) + 1e-8
    x_norm = (x_raw - x_mean) / x_std
    y_norm = (y_raw - y_mean) / y_std

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"Using device: {device}")
    train_loader = make_loader(x_norm, y_norm, train_idx, cfg.batch_size, True, device)
    val_loader = make_loader(x_norm, y_norm, val_idx, cfg.batch_size, False, device)
    tensors = {
        "device": device,
        "y_mean": torch.tensor(y_mean, dtype=torch.float32, device=device),
        "y_std": torch.tensor(y_std, dtype=torch.float32, device=device),
    }

    if model_kind == "gan":
        best_epoch, best_val, history_rows = train_gan_baseline(cfg, train_loader, val_loader, tensors)
    else:
        best_epoch, best_val, history_rows = train_supervised_baseline(model_kind, cfg, train_loader, val_loader, tensors)

    history = pd.DataFrame(history_rows)
    save_training_outputs(history, cfg)
    train_t_values = np.sort(np.unique(round_keys(x_raw[train_idx, 0])))
    save_metadata(cfg, model_kind, x_mean, x_std, y_mean, y_std, val_t_values, train_t_values, best_epoch, best_val, split_source)
    print(f"Training finished. Best epoch={best_epoch}, best validation normalized MSE={best_val:.6e}")
    print(f"Saved model and metadata to: {cfg.model_dir}")


def torch_load(path: str, device: torch.device) -> Dict[str, object]:
    try:
        return torch.load(path, map_location=device, weights_only=False)
    except TypeError:
        return torch.load(path, map_location=device)


def saved_config_to_dataclass(saved: Dict[str, object], fallback: BaselineConfig) -> BaselineConfig:
    names = {field.name for field in fields(BaselineConfig)}
    merged = asdict(fallback)
    for key, value in saved.items():
        if key in names:
            merged[key] = value
    merged["model_dir"] = fallback.model_dir
    merged["analysis_dir"] = fallback.analysis_dir
    return BaselineConfig(**merged)


def predict_baseline(model_kind: str, cfg: BaselineConfig, x_norm: np.ndarray, device: torch.device, batch_size: int) -> np.ndarray:
    checkpoint = torch_load(os.path.join(cfg.model_dir, "best_model.pth"), device)
    if "config" in checkpoint and isinstance(checkpoint["config"], dict):
        cfg = saved_config_to_dataclass(checkpoint["config"], cfg)

    if model_kind == "gan":
        model = make_model("gan_generator", cfg).to(device)
        model.load_state_dict(checkpoint["generator_state"])  # type: ignore[arg-type]
    else:
        model = make_model(model_kind, cfg).to(device)
        model.load_state_dict(checkpoint["model_state"])  # type: ignore[arg-type]

    preds: List[np.ndarray] = []
    model.eval()
    with torch.no_grad():
        for start in range(0, len(x_norm), batch_size):
            batch = torch.tensor(x_norm[start : start + batch_size], dtype=torch.float32, device=device)
            if model_kind == "gan":
                pred = model(batch, torch.zeros((len(batch), cfg.latent_dim), dtype=torch.float32, device=device))
            else:
                pred = model(batch)
            preds.append(pred.cpu().numpy())
    return np.concatenate(preds, axis=0)


def metric_rows(x: np.ndarray, y_true: np.ndarray, y_pred: np.ndarray) -> pd.DataFrame:
    rows: List[Dict[str, object]] = []
    t_keys = round_keys(x[:, 0])
    for mode_idx in range(N_MODES):
        for param_idx, param_name in enumerate(PARAM_NAMES):
            col = mode_idx * N_PARAMS_PER_MODE + param_idx
            err = y_pred[:, col] - y_true[:, col]
            rows.append(
                {
                    "Scope": "all_val",
                    "t_t": "all",
                    "Mode": mode_idx + 1,
                    "Parameter": param_name,
                    "Metric": PLOT_PARAM_NAMES[param_idx],
                    "MSE": float(np.mean(err**2)),
                    "MAE": float(np.mean(np.abs(err))),
                    "MedianAbsError": float(np.median(np.abs(err))),
                    "P95AbsError": float(np.percentile(np.abs(err), 95)),
                    "P99AbsError": float(np.percentile(np.abs(err), 99)),
                    "MaxAbsError": float(np.max(np.abs(err))),
                    "MeanError": float(np.mean(err)),
                }
            )
            for t_key in np.sort(np.unique(t_keys)):
                mask = t_keys == t_key
                t_err = err[mask]
                rows.append(
                    {
                        "Scope": "by_t",
                        "t_t": float(t_key),
                        "Mode": mode_idx + 1,
                        "Parameter": param_name,
                        "Metric": PLOT_PARAM_NAMES[param_idx],
                        "MSE": float(np.mean(t_err**2)),
                        "MAE": float(np.mean(np.abs(t_err))),
                        "MedianAbsError": float(np.median(np.abs(t_err))),
                        "P95AbsError": float(np.percentile(np.abs(t_err), 95)),
                        "P99AbsError": float(np.percentile(np.abs(t_err), 99)),
                        "MaxAbsError": float(np.max(np.abs(t_err))),
                        "MeanError": float(np.mean(t_err)),
                    }
                )
    return pd.DataFrame(rows)


def save_wide_validation_predictions(x: np.ndarray, y_true: np.ndarray, y_pred: np.ndarray, output_dir: str) -> None:
    val_out = pd.DataFrame(x, columns=["t_t", "kx", "ky"])
    for mode_idx in range(N_MODES):
        for param_idx, param_name in enumerate(PARAM_NAMES):
            col = mode_idx * N_PARAMS_PER_MODE + param_idx
            val_out[f"Mode{mode_idx + 1}_{param_name}_True"] = y_true[:, col]
            val_out[f"Mode{mode_idx + 1}_{param_name}_Pred"] = y_pred[:, col]
            val_out[f"Mode{mode_idx + 1}_{param_name}_Error"] = y_pred[:, col] - y_true[:, col]
    val_out.to_excel(os.path.join(output_dir, "Validation_Predictions_All_Params.xlsx"), index=False)


def sci_tex(value: float) -> str:
    if not np.isfinite(value):
        return "nan"
    if value == 0:
        return "0"
    exponent = int(math.floor(math.log10(abs(value))))
    mantissa = value / (10 ** exponent)
    return rf"{mantissa:.2f}\times 10^{{{exponent}}}"


def draw_identity_scatter(ax: plt.Axes, true_vals: np.ndarray, pred_vals: np.ndarray, ylabel: str, xlabel: str) -> None:
    err = pred_vals - true_vals
    mae = float(np.mean(np.abs(err)))
    mse = float(np.mean(err**2))
    ax.scatter(true_vals, pred_vals, s=8, color="#087f83", alpha=0.75, edgecolors="none")
    min_val = min(float(np.min(true_vals)), float(np.min(pred_vals)))
    max_val = max(float(np.max(true_vals)), float(np.max(pred_vals)))
    pad = 0.03 * max(max_val - min_val, 1e-12)
    ax.plot([min_val - pad, max_val + pad], [min_val - pad, max_val + pad], "r--", linewidth=1.4)
    ax.set_xlim(min_val - pad, max_val + pad)
    ax.set_ylim(min_val - pad, max_val + pad)
    ax.set_xlabel(xlabel, fontsize=13)
    ax.set_ylabel(ylabel, fontsize=13)
    ax.text(
        0.10,
        0.90,
        "MAE=$" + sci_tex(mae) + "$\nMSE=$" + sci_tex(mse) + "$",
        transform=ax.transAxes,
        ha="left",
        va="top",
        fontsize=11,
    )
    ax.tick_params(direction="in", length=4, width=1, labelsize=11)
    for spine in ax.spines.values():
        spine.set_linewidth(1.1)


def draw_error_hist(ax: plt.Axes, err: np.ndarray, color: str, label: str, xlabel: str) -> None:
    counts, bins, _ = ax.hist(err, bins=60, color=color, alpha=0.45, edgecolor="#262626", linewidth=0.7, label=label)
    mu = float(np.mean(err))
    sigma = float(np.std(err) + 1e-12)
    xs = np.linspace(float(bins[0]), float(bins[-1]), 400)
    bin_width = float(bins[1] - bins[0]) if len(bins) > 1 else 1.0
    gaussian = len(err) * bin_width * (1.0 / (sigma * math.sqrt(2.0 * math.pi))) * np.exp(-0.5 * ((xs - mu) / sigma) ** 2)
    ax.plot(xs, gaussian, "r--", linewidth=1.5, label="Gaussian\nFitting")
    ax.set_xlabel(xlabel, fontsize=13)
    ax.set_ylabel("Count", fontsize=13)
    ymax = max(float(np.max(counts)) if len(counts) else 1.0, float(np.max(gaussian)) if len(gaussian) else 1.0)
    ax.set_ylim(0, ymax * 1.12)
    ax.legend(frameon=False, fontsize=10, loc="upper left")
    ax.tick_params(direction="in", length=4, width=1, labelsize=11)
    for spine in ax.spines.values():
        spine.set_linewidth(1.1)


def plot_focus_error_distribution(y_true: np.ndarray, y_pred: np.ndarray, output_dir: str, model_name: str) -> pd.DataFrame:
    os.makedirs(output_dir, exist_ok=True)
    specs = [
        (0, "Pred Re($f$) (THz)", "True Re($f$) (THz)", "Re($f$) dist.", "Re($f$) error (THz)", "#8d6fd1"),
        (1, "Pred Im($f$) (THz)", "True Im($f$) (THz)", "Im($f$) dist.", "Im($f$) error (THz)", "#5c84d6"),
        (4, "Pred S$_3$", "True S$_3$", "S$_3$ dist.", "S$_3$ error", "#44bd48"),
    ]

    fig, axes = plt.subplots(2, 3, figsize=(13.6, 6.4))
    metric_summary: List[Dict[str, float]] = []
    rows: List[Dict[str, float]] = []

    for col_idx, (param_idx, y_label, x_label, hist_label, err_label, hist_color) in enumerate(specs):
        cols = [mode_idx * N_PARAMS_PER_MODE + param_idx for mode_idx in range(N_MODES)]
        true_vals = y_true[:, cols].reshape(-1)
        pred_vals = y_pred[:, cols].reshape(-1)
        err = pred_vals - true_vals
        draw_identity_scatter(axes[0, col_idx], true_vals, pred_vals, y_label, x_label)
        draw_error_hist(axes[1, col_idx], err, hist_color, hist_label, err_label)
        metric_summary.append(
            {
                "Parameter": PARAM_NAMES[param_idx],
                "MAE": float(np.mean(np.abs(err))),
                "MSE": float(np.mean(err**2)),
                "MedianAbsError": float(np.median(np.abs(err))),
                "P95AbsError": float(np.percentile(np.abs(err), 95)),
                "P99AbsError": float(np.percentile(np.abs(err), 99)),
                "MaxAbsError": float(np.max(np.abs(err))),
                "MeanError": float(np.mean(err)),
            }
        )
        for tv, pv, ev in zip(true_vals, pred_vals, err):
            rows.append({"Parameter": PARAM_NAMES[param_idx], "True": float(tv), "Pred": float(pv), "Error": float(ev), "Abs_Error": float(abs(ev))})

    border = FancyBboxPatch(
        (0.008, 0.012),
        0.984,
        0.976,
        boxstyle="round,pad=0.006,rounding_size=0.015",
        transform=fig.transFigure,
        fill=False,
        linewidth=1.0,
        edgecolor="#2f5fad",
    )
    fig.patches.append(border)
    fig.tight_layout(rect=[0.02, 0.025, 0.98, 0.98])
    fig.savefig(os.path.join(output_dir, "Validation_Focus_Error_Distribution_All_Modes.png"), dpi=300, bbox_inches="tight")
    plt.close(fig)

    summary_df = pd.DataFrame(metric_summary)
    with pd.ExcelWriter(os.path.join(output_dir, "Validation_Focus_Error_Distribution_All_Modes.xlsx"), engine="openpyxl") as writer:
        summary_df.to_excel(writer, sheet_name="Summary", index=False)
        pd.DataFrame(rows).to_excel(writer, sheet_name="Plot_Data", index=False)
    return summary_df


def analyze_baseline(model_kind: str, cfg: BaselineConfig, csv_path: Optional[str] = None) -> None:
    os.makedirs(cfg.analysis_dir, exist_ok=True)
    csv_path = find_csv_path(csv_path)
    metadata_path = os.path.join(cfg.model_dir, "baseline_metadata.npz")
    checkpoint_path = os.path.join(cfg.model_dir, "best_model.pth")
    if not os.path.exists(metadata_path) or not os.path.exists(checkpoint_path):
        raise FileNotFoundError(f"Missing model or metadata in {cfg.model_dir}; run phase1 training first.")

    meta = np.load(metadata_path, allow_pickle=True)
    if "config_json" in meta.files:
        try:
            cfg = saved_config_to_dataclass(json.loads(str(meta["config_json"].item())), cfg)
        except Exception:
            pass

    x_raw, y_raw = load_raw_data(csv_path)
    train_idx, val_idx, _, _ = make_train_val_split(x_raw, cfg, cfg.analysis_dir, val_t_values=meta["val_t_values"])
    del train_idx

    x_mean = meta["X_mean"]
    x_std = meta["X_std"]
    y_mean = meta["Y_mean"]
    y_std = meta["Y_std"]
    x_val = x_raw[val_idx]
    y_val_true = y_raw[val_idx]
    x_val_norm = (x_val - x_mean) / x_std

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    y_val_pred_norm = predict_baseline(model_kind, cfg, x_val_norm, device, cfg.batch_size)
    y_val_pred = y_val_pred_norm * y_std + y_mean

    save_wide_validation_predictions(x_val, y_val_true, y_val_pred, cfg.analysis_dir)
    all_metrics = metric_rows(x_val, y_val_true, y_val_pred)
    all_metrics.to_excel(os.path.join(cfg.analysis_dir, "All_Params_Metrics.xlsx"), index=False)
    focus_summary = plot_focus_error_distribution(y_val_true, y_val_pred, cfg.analysis_dir, cfg.model_name)

    print("\nFocus validation metrics, four modes combined:")
    print(focus_summary.to_string(index=False))
    print("\nPer-mode validation metrics:")
    print(all_metrics[all_metrics["Scope"] == "all_val"][["Mode", "Parameter", "MAE", "P99AbsError", "MaxAbsError"]].to_string(index=False))
    print(f"\nAnalysis outputs saved to: {cfg.analysis_dir}")


def add_train_args(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--csv", default=None, help="CSV path. Defaults to sibling PIRNN/*GaAs.csv.")
    parser.add_argument("--epochs", type=int, default=None)
    parser.add_argument("--batch-size", type=int, default=None)
    parser.add_argument("--split-mode", choices=["group_t", "random"], default=None)
    parser.add_argument("--val-ratio", type=float, default=None)
    parser.add_argument("--seed", type=int, default=None)
    parser.add_argument("--learning-rate", type=float, default=None)
    parser.add_argument("--weight-decay", type=float, default=None)
    parser.add_argument("--hidden-dim", type=int, default=None)
    parser.add_argument("--num-layers", type=int, default=None)
    parser.add_argument("--dropout", type=float, default=None)
    parser.add_argument("--early-stop-patience", type=int, default=None)
    parser.add_argument("--model-dir", default=None)
    parser.add_argument("--reference-pinn-model-dir", default=None)
    parser.add_argument("--ignore-reference-split", action="store_true")


def add_gan_train_args(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--latent-dim", type=int, default=None)
    parser.add_argument("--adv-weight", type=float, default=None)
    parser.add_argument("--discriminator-lr", type=float, default=None)


def add_plot_args(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--csv", default=None, help="CSV path. Defaults to sibling PIRNN/*GaAs.csv.")
    parser.add_argument("--batch-size", type=int, default=None)
    parser.add_argument("--model-dir", default=None)
    parser.add_argument("--analysis-dir", default=None)


def apply_args_to_config(cfg: BaselineConfig, args: argparse.Namespace, phase: str) -> BaselineConfig:
    for key in [
        "epochs",
        "batch_size",
        "split_mode",
        "val_ratio",
        "seed",
        "learning_rate",
        "weight_decay",
        "hidden_dim",
        "num_layers",
        "dropout",
        "early_stop_patience",
        "model_dir",
        "analysis_dir",
        "reference_pinn_model_dir",
        "latent_dim",
        "adv_weight",
        "discriminator_lr",
    ]:
        if hasattr(args, key):
            value = getattr(args, key)
            if value is not None:
                setattr(cfg, key, value)
    if phase == "train" and getattr(args, "ignore_reference_split", False):
        cfg.use_reference_split = False
    return cfg
