# -*- coding: utf-8 -*-
"""Phase 1: train a simple 1D-CNN baseline on raw CSV mode order."""

from __future__ import annotations

import argparse
import os
import sys


CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
COMPARE_ROOT = os.path.dirname(CURRENT_DIR)
if COMPARE_ROOT not in sys.path:
    sys.path.insert(0, COMPARE_ROOT)

from baseline_common import BaselineConfig, add_train_args, apply_args_to_config, train_baseline


def default_config() -> BaselineConfig:
    return BaselineConfig(
        model_name="CNN",
        model_dir=os.path.join(CURRENT_DIR, "Phase1_CNN_Models_RawModes"),
        analysis_dir=os.path.join(CURRENT_DIR, "Phase2_CNN_Analysis_RawModes"),
        epochs=300,
        learning_rate=8e-4,
        weight_decay=1e-5,
        hidden_dim=96,
        num_layers=2,
        dropout=0.05,
        early_stop_patience=60,
    )


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Train a simple 1D-CNN baseline without mode tracking.")
    add_train_args(parser)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    cfg = apply_args_to_config(default_config(), args, phase="train")
    train_baseline("cnn", cfg, args.csv)


if __name__ == "__main__":
    main()
